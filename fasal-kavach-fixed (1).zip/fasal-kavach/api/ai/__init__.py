"""AI package init."""
