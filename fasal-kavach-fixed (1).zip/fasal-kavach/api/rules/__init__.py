"""Rules package init."""
