"""Ingest package init."""
