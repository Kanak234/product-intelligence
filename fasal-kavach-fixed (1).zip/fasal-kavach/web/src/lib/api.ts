/**
 * API Client — Section 22.6
 *
 * The ONLY file that calls fetch(). Scattered fetch calls are how a frontend
 * becomes impossible to change when the API contract shifts.
 *
 * It is also the only place the auth token is attached. Because every
 * request goes through req(), adding the Authorization header here
 * covers the whole app — there is no route that can accidentally
 * forget it.
 */
import { getToken } from './auth';

// Use relative URLs in browser (Next.js rewrite proxy handles CORS)
// Use absolute URL for server-side fetch
const BASE = typeof window === 'undefined'
  ? (process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:8080')
  : '';

export class ApiError extends Error {
  code: string;
  field?: string;

  constructor(body: Record<string, unknown>) {
    const err = (body?.error ?? body?.detail ?? body) as Record<string, string> | undefined;
    super(err?.message || 'Unknown error');
    this.code = err?.code || 'UNKNOWN';
    this.field = err?.field;
  }
}

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((init?.headers as Record<string, string>) || {}),
  };

  // Attach the Firebase ID token when signed in. When signed out the
  // header is simply absent: the backend answers 401, unless DEMO_MODE
  // is on, in which case it treats the caller as demo_user.
  const token = await getToken().catch(() => null);
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${BASE}${path}`, { ...init, headers });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new ApiError(body);
  }

  return res.json();
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
export interface FarmInput {
  village: string;
  lat: number;
  lon: number;
  crop: string;
  sowing_date: string;
  area_ha: number;
  irrigation: string;
  language: string;
}

export interface Farm {
  farm_id: string;
  grid_id: string;
  growth_stage: string;
  days_after_sowing: number;
  village: string;
  crop: string;
  sowing_date: string;
  area_ha: number;
  irrigation: string;
  language: string;
  created_at: string;
}

export interface Advisory {
  advisory_id: string;
  event_id: string;
  farm_id: string;
  severity: 'LOW' | 'MODERATE' | 'SEVERE';
  rule_id: string;
  headline: string;
  body: string;
  actions: string[];
  spoken_script: string;
  generated_by: 'gemini' | 'template';
  read: boolean;
  window_start: string;
  window_end: string;
  created_at: string;
  language?: string;
}

export interface AdvisoryDetail extends Advisory {
  evidence: Record<string, string | number | boolean>;
  source_note: string;
  forecast_used: Array<{
    date: string;
    rain_mm: number;
    t_max_c: number;
  }>;
}

export interface AdvisoryList {
  farm_id: string;
  count: number;
  advisories: Advisory[];
}

export interface AskInput {
  farm_id: string;
  question: string;
  language: string;
}

export interface AskResult {
  answer_text: string;
  spoken_script: string;
  grounded: boolean;
  used_context: string[];
  confidence_note: string | null;
}

export interface WeatherForecast {
  grid_id: string;
  count: number;
  forecast: Array<{
    date: string;
    t_max_c: number;
    t_min_c: number;
    rain_mm: number;
    humidity_pct: number;
  }>;
}

// ---------------------------------------------------------------------------
// API methods — the contract from Section 18
// ---------------------------------------------------------------------------
export const api = {
  // Farms
  createFarm: (body: FarmInput) =>
    req<Farm>('/api/v1/farms', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  getFarm: (id: string) =>
    req<Farm>(`/api/v1/farms/${id}`),

  updateFarm: (id: string, body: Partial<FarmInput>) =>
    req<Farm>(`/api/v1/farms/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(body),
    }),

  // Advisories
  advisories: (farmId: string, language: string = 'hi') =>
    req<AdvisoryList>(`/api/v1/farms/${farmId}/advisories?language=${language}`),

  advisoryDetail: (id: string) =>
    req<AdvisoryDetail>(`/api/v1/advisories/${id}`),

  // Ask (Bolo Kisan)
  ask: (body: AskInput) =>
    req<AskResult>('/api/v1/ask', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  // Weather
  weather: (gridId: string) =>
    req<WeatherForecast>(`/api/v1/weather/${gridId}`),

  // Feedback
  feedback: (body: { advisory_id: string; farm_id: string; helpful: boolean; acted: boolean }) =>
    req<Record<string, string>>('/api/v1/feedback', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  // Internal
  triggerIngest: () =>
    req<Record<string, unknown>>('/internal/ingest', { method: 'POST' }),

  seedData: () =>
    req<Record<string, unknown>>('/internal/seed', { method: 'POST' }),

  // The signed-in user's own farms — how the app finds your farm after
  // a sign-in on a new device, without trusting localStorage.
  myFarms: () =>
    req<{ owner_uid: string; count: number; farms: Farm[] }>('/api/v1/me/farms'),

  // Health
  health: () => req<Record<string, string>>('/healthz'),

  // Is the backend actually persisting? Check before demoing.
  storageStatus: () =>
    req<{ backend: string; persistent: boolean; farms_stored: number }>(
      '/internal/status'
    ),
};
