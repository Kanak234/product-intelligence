/**
 * auth.ts — Phone sign-in, and the token every API call carries.
 *
 * WHY THIS FILE EXISTS
 * --------------------
 * Before this, the app had no login at all. The farm id sat in
 * localStorage and the backend stamped every farm with the same
 * hardcoded owner. Anyone who guessed a farm id could read that
 * farmer's advisories.
 *
 * THE FLOW
 * --------
 *   1. Farmer types a 10-digit mobile number.
 *   2. Firebase sends an OTP by SMS.
 *   3. Farmer types the 6-digit code.
 *   4. Firebase returns a signed ID token, valid one hour.
 *   5. Every API call sends it as: Authorization: Bearer <token>
 *   6. api/auth.py verifies the signature against Google's public keys.
 *
 * The token cannot be forged. That is what makes ownership checks real.
 *
 * getIdToken() refreshes automatically when the hour is up, so nothing
 * here needs to manage expiry.
 *
 * DEMO MODE
 * ---------
 * NEXT_PUBLIC_DEMO_MODE=true lets the app run with no sign-in, as
 * "demo_user". Judges can tap through without waiting for an SMS.
 * It is a labelled flag, not a hidden bypass — say so on stage, and
 * show real phone sign-in working alongside it.
 */

import {
  RecaptchaVerifier,
  signInWithPhoneNumber,
  signOut,
  onAuthStateChanged,
  type ConfirmationResult,
  type User,
} from 'firebase/auth';
import { getFirebaseAuth, isFirebaseConfigured } from './firebase';

export const DEMO_MODE = process.env.NEXT_PUBLIC_DEMO_MODE !== 'false';

let confirmationResult: ConfirmationResult | null = null;
let recaptcha: RecaptchaVerifier | null = null;

/** Firebase is unusable without a configured project. */
export function canSignIn(): boolean {
  return isFirebaseConfigured();
}

/**
 * Normalise what a farmer actually types into E.164.
 * People enter "9876543210", "09876543210", "+91 98765 43210".
 * Firebase accepts exactly one of those.
 */
export function toE164(raw: string): string | null {
  const digits = raw.replace(/\D/g, '');
  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 11 && digits.startsWith('0')) return `+91${digits.slice(1)}`;
  if (digits.length === 12 && digits.startsWith('91')) return `+${digits}`;
  if (digits.length === 13 && digits.startsWith('091')) return `+${digits.slice(1)}`;
  return null;
}

/**
 * Invisible reCAPTCHA. Firebase requires it for phone auth — it is what
 * stops someone burning your SMS quota with a script.
 */
function ensureRecaptcha(containerId: string): RecaptchaVerifier {
  const auth = getFirebaseAuth();
  if (!auth) throw new Error('Firebase is not configured.');
  if (!recaptcha) {
    recaptcha = new RecaptchaVerifier(auth, containerId, { size: 'invisible' });
  }
  return recaptcha;
}

/** Step 1: send the OTP. Returns a friendly error string, or null on success. */
export async function sendOtp(phoneRaw: string, containerId: string): Promise<string | null> {
  const auth = getFirebaseAuth();
  if (!auth) return 'Sign-in is not configured on this build.';

  const phone = toE164(phoneRaw);
  if (!phone) return 'Enter a 10-digit mobile number.';

  try {
    const verifier = ensureRecaptcha(containerId);
    confirmationResult = await signInWithPhoneNumber(auth, phone, verifier);
    return null;
  } catch (err: unknown) {
    // A failed attempt leaves the widget in a dead state; rebuild it.
    try {
      recaptcha?.clear();
    } catch {
      /* already gone */
    }
    recaptcha = null;
    return friendlyError(err);
  }
}

/** Step 2: confirm the code. Returns an error string, or null on success. */
export async function confirmOtp(code: string): Promise<string | null> {
  if (!confirmationResult) return 'Request a code first.';
  const clean = code.replace(/\D/g, '');
  if (clean.length < 6) return 'Enter the 6-digit code.';

  try {
    await confirmationResult.confirm(clean);
    confirmationResult = null;
    return null;
  } catch (err: unknown) {
    return friendlyError(err);
  }
}

/**
 * The token for the next API call, or null when signed out.
 * api.ts calls this before every request.
 */
export async function getToken(): Promise<string | null> {
  const auth = getFirebaseAuth();
  if (!auth?.currentUser) return null;
  try {
    return await auth.currentUser.getIdToken();
  } catch {
    return null;
  }
}

export function currentUser(): User | null {
  return getFirebaseAuth()?.currentUser ?? null;
}

export function isSignedIn(): boolean {
  return Boolean(currentUser());
}

/** Firebase restores the session asynchronously on page load; wait for it. */
export function watchAuth(cb: (user: User | null) => void): () => void {
  const auth = getFirebaseAuth();
  if (!auth) {
    cb(null);
    return () => {};
  }
  return onAuthStateChanged(auth, cb);
}

export async function signOutUser(): Promise<void> {
  const auth = getFirebaseAuth();
  if (auth) await signOut(auth);
  localStorage.removeItem('fk_farm_id');
  confirmationResult = null;
}

/**
 * Firebase error codes are for developers. Farmers get sentences.
 */
function friendlyError(err: unknown): string {
  const code = (err as { code?: string })?.code || '';
  switch (code) {
    case 'auth/invalid-phone-number':
      return 'That mobile number does not look right.';
    case 'auth/invalid-verification-code':
      return 'That code is wrong. Check the SMS and try again.';
    case 'auth/code-expired':
      return 'That code has expired. Request a new one.';
    case 'auth/too-many-requests':
      return 'Too many attempts. Wait a few minutes and try again.';
    case 'auth/quota-exceeded':
      return 'Daily SMS limit reached. Use demo mode for now.';
    case 'auth/network-request-failed':
      return 'No internet connection. Check your network.';
    case 'auth/operation-not-allowed':
      return 'Phone sign-in is not enabled in the Firebase console.';
    default:
      return (err as Error)?.message || 'Something went wrong. Try again.';
  }
}
