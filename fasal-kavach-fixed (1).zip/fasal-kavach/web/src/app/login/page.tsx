"use client";
/**
 * Login — phone number + OTP.
 *
 * Design constraints, all from Section 21:
 *   - Large tap targets. This is used outdoors, on a cheap phone,
 *     sometimes by someone in their sixties.
 *   - One field visible at a time. Two inputs on one screen is where
 *     first-time users stall.
 *   - Errors are sentences, not codes.
 *   - Demo mode is visible and labelled, never silent.
 */
import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { t, type Lang } from "@/lib/i18n";
import {
  sendOtp,
  confirmOtp,
  canSignIn,
  watchAuth,
  DEMO_MODE,
} from "@/lib/auth";
import { api } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [lang, setLang] = useState<Lang>("hi");
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [resendIn, setResendIn] = useState(0);
  const recaptchaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const stored = localStorage.getItem("fk_lang") as Lang | null;
    if (stored) setLang(stored);
  }, []);

  // If Firebase restores a session, skip straight past this screen.
  useEffect(() => {
    return watchAuth(async (user) => {
      if (!user) return;
      await routeAfterSignIn();
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Resend cooldown — stops people hammering the button and burning quota.
  useEffect(() => {
    if (resendIn <= 0) return;
    const id = setTimeout(() => setResendIn((n) => n - 1), 1000);
    return () => clearTimeout(id);
  }, [resendIn]);

  /**
   * After sign-in, ask the API which farms this account owns.
   * localStorage is a cache, not a source of truth — on a new phone it
   * is empty, and the farm must still be found.
   */
  async function routeAfterSignIn() {
    try {
      const mine = await api.myFarms();
      if (mine.count > 0) {
        localStorage.setItem("fk_farm_id", mine.farms[0].farm_id);
        router.replace(`/farm/${mine.farms[0].farm_id}`);
        return;
      }
    } catch {
      /* fall through to onboarding */
    }
    router.replace("/onboarding");
  }

  async function handleSendOtp() {
    setBusy(true);
    setError("");
    const err = await sendOtp(phone, "recaptcha-container");
    setBusy(false);
    if (err) {
      setError(err);
      return;
    }
    setStep("otp");
    setResendIn(30);
  }

  async function handleConfirm() {
    setBusy(true);
    setError("");
    const err = await confirmOtp(code);
    setBusy(false);
    if (err) {
      setError(err);
      return;
    }
    await routeAfterSignIn();
  }

  function useDemoAccount() {
    localStorage.setItem("fk_demo", "true");
    localStorage.setItem("fk_farm_id", "f_demo_01");
    router.push("/farm/f_demo_01");
  }

  const configured = canSignIn();

  return (
    <main
      style={{
        minHeight: "100dvh",
        background: "var(--surface-alt)",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div className="top-header" style={{ textAlign: "center", padding: "32px 24px 24px" }}>
        <div style={{ fontSize: "2.5rem", marginBottom: "8px" }}>🌾</div>
        <h1 style={{ fontSize: "1.75rem", fontWeight: 800, color: "white", margin: 0 }}>
          Fasal Kavach
        </h1>
        <p style={{ color: "rgba(255,255,255,0.8)", fontSize: "0.9rem", marginTop: "4px" }}>
          {t("login.subtitle", lang)}
        </p>
      </div>

      <div style={{ flex: 1, padding: "32px 24px", maxWidth: 420, margin: "0 auto", width: "100%" }}>
        {step === "phone" && (
          <>
            <label
              htmlFor="phone"
              style={{ display: "block", fontWeight: 700, marginBottom: 8, fontSize: "1.05rem" }}
            >
              {t("login.phone", lang)}
            </label>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span
                style={{
                  padding: "16px 12px",
                  background: "var(--surface)",
                  border: "2px solid var(--border)",
                  borderRadius: 12,
                  fontWeight: 700,
                  fontSize: "1.1rem",
                }}
              >
                +91
              </span>
              <input
                id="phone"
                type="tel"
                inputMode="numeric"
                autoComplete="tel"
                maxLength={10}
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="98765 43210"
                disabled={!configured || busy}
                style={{
                  flex: 1,
                  padding: "16px",
                  fontSize: "1.25rem",
                  letterSpacing: "0.05em",
                  border: "2px solid var(--border)",
                  borderRadius: 12,
                  background: "var(--surface)",
                }}
              />
            </div>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem", marginTop: 10 }}>
              {t("login.smsNote", lang)}
            </p>

            <button
              onClick={handleSendOtp}
              disabled={!configured || busy || phone.replace(/\D/g, "").length < 10}
              style={primaryBtn(busy || !configured)}
            >
              {busy ? t("login.sending", lang) : t("login.sendOtp", lang)}
            </button>
          </>
        )}

        {step === "otp" && (
          <>
            <label
              htmlFor="otp"
              style={{ display: "block", fontWeight: 700, marginBottom: 8, fontSize: "1.05rem" }}
            >
              {t("login.enterOtp", lang)}
            </label>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", marginBottom: 12 }}>
              +91 {phone}{" "}
              <button
                onClick={() => {
                  setStep("phone");
                  setCode("");
                  setError("");
                }}
                style={{
                  background: "none",
                  border: "none",
                  color: "var(--accent)",
                  fontWeight: 600,
                  cursor: "pointer",
                }}
              >
                {t("login.change", lang)}
              </button>
            </p>
            <input
              id="otp"
              type="tel"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="------"
              disabled={busy}
              style={{
                width: "100%",
                padding: "16px",
                fontSize: "1.75rem",
                textAlign: "center",
                letterSpacing: "0.5em",
                border: "2px solid var(--border)",
                borderRadius: 12,
                background: "var(--surface)",
              }}
            />

            <button
              onClick={handleConfirm}
              disabled={busy || code.replace(/\D/g, "").length < 6}
              style={primaryBtn(busy)}
            >
              {busy ? t("login.verifying", lang) : t("login.verify", lang)}
            </button>

            <button
              onClick={handleSendOtp}
              disabled={resendIn > 0 || busy}
              style={{
                width: "100%",
                marginTop: 12,
                background: "none",
                border: "none",
                color: resendIn > 0 ? "var(--text-secondary)" : "var(--accent)",
                fontWeight: 600,
                fontSize: "0.95rem",
                cursor: resendIn > 0 ? "default" : "pointer",
              }}
            >
              {resendIn > 0
                ? `${t("login.resendIn", lang)} ${resendIn}s`
                : t("login.resend", lang)}
            </button>
          </>
        )}

        {error && (
          <div
            role="alert"
            style={{
              marginTop: 16,
              padding: "12px 14px",
              borderRadius: 10,
              background: "#FDECEA",
              color: "#8A1C11",
              fontSize: "0.95rem",
              border: "1px solid #F5C2BC",
            }}
          >
            {error}
          </div>
        )}

        {!configured && (
          <div
            style={{
              marginTop: 16,
              padding: "12px 14px",
              borderRadius: 10,
              background: "#FFF6E5",
              color: "#7A4A00",
              fontSize: "0.9rem",
              border: "1px solid #F0DCB4",
            }}
          >
            {t("login.notConfigured", lang)}
          </div>
        )}

        {/* Invisible reCAPTCHA mounts here. Firebase requires the node
            to exist before signInWithPhoneNumber is called. */}
        <div id="recaptcha-container" ref={recaptchaRef} />
      </div>

      {DEMO_MODE && (
        <div style={{ padding: "16px 24px 40px", textAlign: "center" }}>
          <button
            onClick={useDemoAccount}
            style={{
              color: "var(--accent)",
              background: "none",
              border: "none",
              cursor: "pointer",
              fontSize: "0.95rem",
              fontWeight: 600,
            }}
          >
            {t("login.demo", lang)}
          </button>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.78rem", marginTop: 6 }}>
            {t("login.demoNote", lang)}
          </p>
        </div>
      )}
    </main>
  );
}

function primaryBtn(disabled: boolean): React.CSSProperties {
  return {
    width: "100%",
    marginTop: 24,
    padding: "18px",
    fontSize: "1.15rem",
    fontWeight: 700,
    color: "white",
    background: disabled ? "var(--text-secondary)" : "var(--accent)",
    border: "none",
    borderRadius: 12,
    cursor: disabled ? "default" : "pointer",
  };
}
