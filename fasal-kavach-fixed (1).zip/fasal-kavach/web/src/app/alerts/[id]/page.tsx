"use client";
import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { api, type AdvisoryDetail } from "@/lib/api";
import { t, type Lang } from "@/lib/i18n";
import { speak, stopSpeaking } from "@/lib/tts";

const SEV_COLOR = { SEVERE: "var(--severe)", MODERATE: "var(--moderate)", LOW: "var(--low)" };
const SEV_BG = { SEVERE: "var(--severe-bg)", MODERATE: "var(--moderate-bg)", LOW: "var(--low-bg)" };
const SEV_ICON = { SEVERE: "⚠️", MODERATE: "⚡", LOW: "ℹ️" };

// Friendly labels for evidence keys
const EVIDENCE_LABELS: Record<string, { en: string; hi: string }> = {
  rain_mm_next_48h: { en: "Rain expected in 2 days", hi: "2 दिनों में बारिश" },
  threshold_mm: { en: "Safe limit for your crop", hi: "आपकी फसल की सुरक्षित सीमा" },
  baseline_p90_mm: { en: "Normal for this week", hi: "इस सप्ताह का सामान्य" },
  rain_mm_3day: { en: "Rain over 3 days", hi: "3 दिनों में बारिश" },
  t_max_peak_c: { en: "Peak temperature", hi: "अधिकतम तापमान" },
  threshold_c: { en: "Safe temperature limit", hi: "सुरक्षित तापमान सीमा" },
  hot_days_count: { en: "Hot days in forecast", hi: "गर्म दिनों की संख्या" },
  dry_days_forecast: { en: "Dry days ahead", hi: "सूखे दिन" },
  t_min_lowest_c: { en: "Lowest temperature", hi: "न्यूनतम तापमान" },
  days_since_sowing: { en: "Days since sowing", hi: "बुवाई के बाद के दिन" },
  stage_window: { en: "Crop stage", hi: "फसल चरण" },
  humidity_pct_avg: { en: "Average humidity", hi: "औसत नमी" },
  rain_mm_in_window: { en: "Rain in harvest window", hi: "कटाई अवधि में बारिश" },
};

function formatEvidenceValue(key: string, val: string | number | boolean): string {
  if (typeof val === "number") {
    if (key.includes("_mm")) return `${val} mm`;
    if (key.includes("_c")) return `${val}°C`;
    if (key.includes("_pct")) return `${val}%`;
    if (key.includes("days")) return `${val} days`;
    return String(val);
  }
  return String(val);
}

export default function AlertDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [lang, setLang] = useState<Lang>("hi");
  const [adv, setAdv] = useState<AdvisoryDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [speaking, setSpeaking] = useState(false);
  const [thanksFeedback, setThanksFeedback] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("fk_lang") as Lang | null;
    if (stored) setLang(stored);
  }, []);

  useEffect(() => {
    api.advisoryDetail(id)
      .then(data => { setAdv(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [id]);

  function toggleSpeak() {
    if (!adv) return;
    if (speaking) {
      stopSpeaking();
      setSpeaking(false);
    } else {
      const { supported } = speak(adv.spoken_script, lang);
      if (supported) {
        setSpeaking(true);
        const u = new SpeechSynthesisUtterance(adv.spoken_script);
        u.onend = () => setSpeaking(false);
      }
    }
  }

  async function submitFeedback(helpful: boolean) {
    if (!adv) return;
    try {
      await api.feedback({ advisory_id: adv.advisory_id, farm_id: adv.farm_id, helpful, acted: helpful });
      setThanksFeedback(true);
    } catch { /* ignore */ }
  }

  if (loading) {
    return (
      <main style={{ minHeight: "100dvh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div className="spinner" />
      </main>
    );
  }

  if (!adv) {
    return (
      <main style={{ minHeight: "100dvh", padding: "24px" }}>
        <button onClick={() => router.back()} className="btn-secondary">← Back</button>
        <p style={{ marginTop: "24px", color: "var(--text-secondary)" }}>Advisory not found.</p>
      </main>
    );
  }

  const sev = adv.severity as "SEVERE" | "MODERATE" | "LOW";

  return (
    <main style={{ minHeight: "100dvh", background: "var(--surface-alt)" }}>
      {/* Header */}
      <div className="top-header" style={{ background: SEV_COLOR[sev] }}>
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <button onClick={() => router.back()} style={{ background: "none", border: "none", color: "white", fontSize: "1.3rem", cursor: "pointer", minWidth: 44, minHeight: 44 }}>←</button>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <span style={{ fontSize: "1.2rem" }}>{SEV_ICON[sev]}</span>
              <span style={{ color: "white", fontWeight: 700, fontSize: "0.85rem" }}>{t(`severity.${sev}`, lang)}</span>
              {adv.generated_by === "template" && (
                <span style={{ background: "rgba(255,255,255,0.25)", color: "white", padding: "2px 8px", borderRadius: "999px", fontSize: "0.7rem" }}>
                  📋 Basic
                </span>
              )}
            </div>
            <h1 style={{ color: "white", fontSize: "1rem", fontWeight: 700, margin: "4px 0 0" }}>
              {adv.headline}
            </h1>
          </div>
        </div>
      </div>

      <div className="page-content">
        {/* Body */}
        <div style={{ background: SEV_BG[sev], border: `1px solid`, borderColor: sev === "SEVERE" ? "var(--severe-border)" : sev === "MODERATE" ? "var(--moderate-border)" : "var(--low-border)", borderRadius: "16px", padding: "16px", marginBottom: "16px" }}>
          <p style={{ fontSize: "1rem", lineHeight: 1.7, margin: 0 }}>{adv.body}</p>
        </div>

        {/* Actions */}
        <div style={{ background: "white", borderRadius: "16px", padding: "16px", marginBottom: "16px", boxShadow: "var(--shadow-card)" }}>
          <h2 style={{ fontSize: "0.85rem", fontWeight: 700, color: "var(--text-muted)", marginBottom: "12px", textTransform: "uppercase", letterSpacing: "0.05em" }}>
            {lang === "hi" ? "क्या करें" : "Actions"}
          </h2>
          {adv.actions.map((action, i) => (
            <div key={i} style={{ display: "flex", gap: "12px", padding: "10px 0", borderBottom: i < adv.actions.length - 1 ? "1px solid #EEF0EE" : "none" }}>
              <div style={{ width: "24px", height: "24px", borderRadius: "50%", background: SEV_COLOR[sev], color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.75rem", fontWeight: 700, flexShrink: 0 }}>
                {i + 1}
              </div>
              <p style={{ margin: 0, fontSize: "0.95rem", lineHeight: 1.5 }}>{action}</p>
            </div>
          ))}
        </div>

        {/* Speak button */}
        <button className={`speak-btn ${speaking ? "speaking" : ""}`} onClick={toggleSpeak} style={{ width: "100%", marginBottom: "16px", fontSize: "1rem" }}>
          {speaking ? `🔊 ${t("alert.stop", lang)}` : `▶ ${t("alert.listen", lang)}`}
        </button>

        {/* Evidence — Kya hua? */}
        {adv.evidence && Object.keys(adv.evidence).length > 0 && (
          <div className="evidence-panel" style={{ marginBottom: "16px" }}>
            <h2 style={{ fontSize: "1rem", fontWeight: 700, marginBottom: "12px", color: "var(--text-primary)" }}>
              🔍 {t("evidence.title", lang)}
            </h2>
            {Object.entries(adv.evidence)
              .filter(([k]) => !k.includes("observed_at"))
              .map(([key, val]) => {
                const label = EVIDENCE_LABELS[key];
                return (
                  <div key={key} className="evidence-row">
                    <span className="evidence-label">
                      {label ? (lang === "hi" ? label.hi : label.en) : key.replace(/_/g, " ")}
                    </span>
                    <span className="evidence-value">{formatEvidenceValue(key, val)}</span>
                  </div>
                );
              })}
            {adv.source_note && (
              <div style={{ marginTop: "12px", padding: "8px 0", borderTop: "1px solid #E0E5E0", fontSize: "0.75rem", color: "var(--text-muted)" }}>
                📖 {t("evidence.source", lang)}: {adv.source_note}
              </div>
            )}
            <div style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginTop: "4px" }}>
              📡 {t("evidence.data", lang)}
            </div>
          </div>
        )}

        {/* Forecast used */}
        {adv.forecast_used && adv.forecast_used.length > 0 && (
          <div style={{ background: "white", borderRadius: "16px", padding: "16px", marginBottom: "16px", boxShadow: "var(--shadow-card)" }}>
            <h2 style={{ fontSize: "0.85rem", fontWeight: 700, color: "var(--text-muted)", marginBottom: "12px", textTransform: "uppercase", letterSpacing: "0.05em" }}>
              {lang === "hi" ? "पूर्वानुमान डेटा" : "Forecast Used"}
            </h2>
            {adv.forecast_used.map(day => (
              <div key={day.date} className="evidence-row">
                <span className="evidence-label">{day.date}</span>
                <span className="evidence-value" style={{ fontSize: "0.85rem" }}>
                  🌧 {day.rain_mm}mm &nbsp;🌡 {day.t_max_c}°C
                </span>
              </div>
            ))}
          </div>
        )}

        {/* Feedback */}
        <div style={{ background: "white", borderRadius: "16px", padding: "16px", marginBottom: "16px", boxShadow: "var(--shadow-card)", textAlign: "center" }}>
          {thanksFeedback ? (
            <p style={{ color: "var(--accent)", fontWeight: 600 }}>✓ {t("feedback.thanks", lang)}</p>
          ) : (
            <>
              <p style={{ marginBottom: "12px", fontSize: "0.9rem", color: "var(--text-secondary)" }}>
                {t("alert.helpful", lang)}
              </p>
              <div style={{ display: "flex", gap: "12px", justifyContent: "center" }}>
                <button className="btn-primary" onClick={() => submitFeedback(true)} style={{ minWidth: "80px" }}>
                  👍 {t("alert.yes", lang)}
                </button>
                <button className="btn-secondary" onClick={() => submitFeedback(false)} style={{ minWidth: "80px" }}>
                  👎 {t("alert.no", lang)}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </main>
  );
}
