"use client";
import { useState, useEffect, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import { api, type Advisory, type Farm } from "@/lib/api";
import { t, type Lang } from "@/lib/i18n";
import { speak, stopSpeaking } from "@/lib/tts";
import { signOutUser } from "@/lib/auth";

// ─── Severity helpers ───────────────────────────────────────────────────────
const SEV_ICON = { SEVERE: "⚠️", MODERATE: "⚡", LOW: "ℹ️" };
const SEV_COLOR = { SEVERE: "var(--severe)", MODERATE: "var(--moderate)", LOW: "var(--low)" };

// ─── Alert Card ──────────────────────────────────────────────────────────────
function AlertCard({ adv, lang, onOpen }: { adv: Advisory; lang: Lang; onOpen: (id: string) => void }) {
  const [speaking, setSpeaking] = useState(false);

  function toggleSpeak(e: React.MouseEvent) {
    e.stopPropagation();
    if (speaking) {
      stopSpeaking();
      setSpeaking(false);
    } else {
      const { supported } = speak(adv.spoken_script, lang);
      if (supported) {
        setSpeaking(true);
        // Reset when done
        const u = new SpeechSynthesisUtterance(adv.spoken_script);
        u.onend = () => setSpeaking(false);
      }
    }
  }

  return (
    <div
      className={`alert-card ${adv.severity.toLowerCase()} ${!adv.read ? "unread" : ""} fade-in`}
      onClick={() => onOpen(adv.advisory_id)}
      style={{ marginBottom: "12px", paddingLeft: "20px" }}
    >
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "8px" }}>
        <div style={{ flex: 1 }}>
          {/* Severity badge */}
          <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "6px" }}>
            <span style={{ fontSize: "1.1rem" }}>{SEV_ICON[adv.severity]}</span>
            <span className={`severity-badge ${adv.severity.toLowerCase()}`}>
              {t(`severity.${adv.severity}`, lang)}
            </span>
            {adv.generated_by === "template" && (
              <span className="template-badge">📋 {t("template.badge", lang)}</span>
            )}
            <span style={{ color: "var(--text-muted)", fontSize: "0.75rem", marginLeft: "auto" }}>
              {adv.window_start}
            </span>
          </div>
          {/* Headline */}
          <h3 style={{ fontSize: "1rem", fontWeight: 700, margin: "0 0 4px", color: SEV_COLOR[adv.severity] }}>
            {adv.headline}
          </h3>
          {/* Body */}
          <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)", margin: 0, lineHeight: 1.5 }}>
            {adv.body}
          </p>
        </div>
      </div>

      {/* Speak button */}
      <div style={{ marginTop: "12px", display: "flex", gap: "8px" }}>
        <button
          className={`speak-btn ${speaking ? "speaking" : ""}`}
          onClick={toggleSpeak}
          style={{ flex: 1 }}
        >
          {speaking ? "🔊 " + t("alert.stop", lang) : "▶ " + t("alert.listen", lang)}
        </button>
        <button
          className="btn-secondary"
          onClick={e => { e.stopPropagation(); onOpen(adv.advisory_id); }}
          style={{ fontSize: "0.8rem", padding: "8px 12px", minHeight: "48px" }}
        >
          {t("alert.why", lang)}
        </button>
      </div>
    </div>
  );
}

// ─── Main farm/alerts page ───────────────────────────────────────────────────
export default function FarmPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [lang, setLang] = useState<Lang>("hi");
  const [farm, setFarm] = useState<Farm | null>(null);
  const [advisories, setAdvisories] = useState<Advisory[]>([]);
  const [loading, setLoading] = useState(true);
  const [ingesting, setIngesting] = useState(false);
  const [activeTab, setActiveTab] = useState<"alerts" | "ask" | "farm">("alerts");
  const [lastUpdated, setLastUpdated] = useState<string>("");
  const [isOffline, setIsOffline] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("fk_lang") as Lang | null;
    if (stored) setLang(stored);
    setIsOffline(!navigator.onLine);
    window.addEventListener("offline", () => setIsOffline(true));
    window.addEventListener("online", () => setIsOffline(false));
  }, []);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [farmData, advData] = await Promise.all([
        api.getFarm(id),
        api.advisories(id, lang),
      ]);
      setFarm(farmData);
      setAdvisories(advData.advisories);
      setLastUpdated(new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }));
    } catch {
      // Try to serve from cache silently
    } finally {
      setLoading(false);
    }
  }, [id, lang]);

  useEffect(() => { loadData(); }, [loadData]);

  async function runIngest() {
    setIngesting(true);
    try {
      await api.triggerIngest();
      await loadData();
    } catch (e) {
      console.error("Ingest failed:", e);
    } finally {
      setIngesting(false);
    }
  }

  /** Sign out and return to the start. Clears the cached farm id too. */
  async function handleSignOut() {
    await signOutUser();
    localStorage.removeItem("fk_demo");
    router.replace("/");
  }

  const sortedAdvisories = [...advisories].sort((a, b) => {
    const sevOrder = { SEVERE: 0, MODERATE: 1, LOW: 2 };
    if (sevOrder[a.severity] !== sevOrder[b.severity]) return sevOrder[a.severity] - sevOrder[b.severity];
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });

  // Capture the current tab value with the full union type so TypeScript doesn't
  // narrow it after the early-return guards below (which would break the nav bar).
  const currentTab: "alerts" | "ask" | "farm" = activeTab;

  if (currentTab === "ask") {
    return <AskTab farmId={id} lang={lang} onBack={() => setActiveTab("alerts")} />;
  }
  if (currentTab === "farm") {
    return <FarmTab farm={farm} lang={lang} farmId={id} onBack={() => setActiveTab("alerts")} onSave={loadData} />;
  }

  return (
    <main style={{ minHeight: "100dvh", background: "var(--surface-alt)" }}>
      {/* Top header */}
      <div className="top-header">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <h1 style={{ fontSize: "1rem", fontWeight: 700, color: "white", margin: 0 }}>
              🌾 {farm?.village || "..."} &bull; {t(`crop.${farm?.crop || "paddy"}`, lang)}
            </h1>
            <p style={{ color: "rgba(255,255,255,0.7)", fontSize: "0.75rem", margin: "2px 0 0" }}>
              {farm ? `${farm.growth_stage.replace(/_/g, " ")} (${farm.days_after_sowing} DAS)` : "Loading..."}
            </p>
          </div>
          <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
            <button
              onClick={runIngest}
              disabled={ingesting}
              style={{ background: "rgba(255,255,255,0.2)", border: "none", borderRadius: "8px", padding: "6px 10px", color: "white", cursor: "pointer", fontSize: "0.75rem" }}
            >
              {ingesting ? "⏳" : "🔄"}
            </button>
            {/* Without this there is no way off a signed-in account —
                you cannot switch farmers, and you cannot show a judge
                that sign-in is real rather than decorative. */}
            <button
              onClick={handleSignOut}
              title={t("login.signOut", lang)}
              style={{ background: "rgba(255,255,255,0.2)", border: "none", borderRadius: "8px", padding: "6px 10px", color: "white", cursor: "pointer", fontSize: "0.75rem" }}
            >
              ⏻
            </button>
          </div>
        </div>
      </div>

      {isOffline && (
        <div className="offline-banner">⚡ {t("error.offline", lang)}</div>
      )}

      <div className="page-content">
        {loading ? (
          <div style={{ textAlign: "center", padding: "48px 16px" }}>
            <div className="spinner" style={{ margin: "0 auto" }} />
          </div>
        ) : sortedAdvisories.length === 0 ? (
          <div className="empty-state">
            <div style={{ fontSize: "4rem", marginBottom: "16px" }}>✅</div>
            <h3 style={{ fontSize: "1.1rem", fontWeight: 700, marginBottom: "8px" }}>{t("empty.title", lang)}</h3>
            <p style={{ fontSize: "0.9rem" }}>{t("empty.body", lang)}</p>
            <p style={{ fontSize: "0.8rem", color: "var(--text-muted)", marginTop: "16px" }}>
              {t("forecast.updated", lang)} {lastUpdated}
            </p>
          </div>
        ) : (
          <>
            {sortedAdvisories.map(adv => (
              <AlertCard
                key={adv.advisory_id}
                adv={adv}
                lang={lang}
                onOpen={(advId) => router.push(`/alerts/${advId}`)}
              />
            ))}
            <p style={{ textAlign: "center", fontSize: "0.75rem", color: "var(--text-muted)", marginTop: "8px" }}>
              {t("forecast.updated", lang)} {lastUpdated}
            </p>
          </>
        )}
      </div>

      {/* Bottom navigation */}
      <nav className="nav-bar">
        <button className={`nav-item ${activeTab === "alerts" ? "active" : ""}`} onClick={() => setActiveTab("alerts")}>
          <span style={{ fontSize: "1.3rem" }}>🔔</span>
          <span>{t("nav.alerts", lang)}</span>
        </button>
        <button className={`nav-item ${activeTab === "ask" ? "active" : ""}`} onClick={() => setActiveTab("ask")}>
          <span style={{ fontSize: "1.3rem" }}>🎤</span>
          <span>{t("nav.ask", lang)}</span>
        </button>
        <button className={`nav-item ${activeTab === "farm" ? "active" : ""}`} onClick={() => setActiveTab("farm")}>
          <span style={{ fontSize: "1.3rem" }}>🌾</span>
          <span>{t("nav.farm", lang)}</span>
        </button>
      </nav>
    </main>
  );
}

// ─── Bolo Kisan tab ──────────────────────────────────────────────────────────
function AskTab({ farmId, lang, onBack }: { farmId: string; lang: Lang; onBack: () => void }) {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<{ text: string; spoken: string; grounded: boolean } | null>(null);
  const [loading, setLoading] = useState(false);
  const [listening, setListening] = useState(false);

  async function submitQuestion(q: string) {
    if (!q.trim()) return;
    setLoading(true);
    setAnswer(null);
    try {
      const res = await api.ask({ farm_id: farmId, question: q, language: lang });
      setAnswer({ text: res.answer_text, spoken: res.spoken_script, grounded: res.grounded });
      speak(res.spoken_script, lang);
    } catch {
      setAnswer({ text: "Could not get an answer. Please try again.", spoken: "", grounded: false });
    } finally {
      setLoading(false);
    }
  }

  function startVoice() {
    /* eslint-disable @typescript-eslint/no-explicit-any */
    const SR = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (!SR) { alert("Voice not supported on this browser."); return; }
    const rec = new SR();
    rec.lang = lang === "hi" ? "hi-IN" : lang === "bn" ? "bn-IN" : "hi-IN";
    rec.interimResults = false;
    rec.continuous = false;
    setListening(true);
    rec.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      setQuestion(transcript);
      setListening(false);
      submitQuestion(transcript);
    };
    rec.onerror = () => setListening(false);
    rec.onend = () => setListening(false);
    /* eslint-enable @typescript-eslint/no-explicit-any */
    rec.start();
  }

  return (
    <main style={{ minHeight: "100dvh", background: "var(--surface-alt)" }}>
      <div className="top-header">
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <button onClick={onBack} style={{ background: "none", border: "none", color: "white", fontSize: "1.2rem", cursor: "pointer" }}>←</button>
          <div>
            <h1 style={{ fontSize: "1.1rem", fontWeight: 700, color: "white", margin: 0 }}>{t("ask.title", lang)}</h1>
            <p style={{ color: "rgba(255,255,255,0.7)", fontSize: "0.75rem", margin: 0 }}>{t("ask.subtitle", lang)}</p>
          </div>
        </div>
      </div>

      <div className="page-content" style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "24px" }}>
        {/* Voice button */}
        <button
          className={`voice-btn ${listening ? "recording" : ""}`}
          onMouseDown={startVoice}
          style={{ marginTop: "16px" }}
        >
          <span style={{ fontSize: "1.8rem" }}>{listening ? "🔴" : "🎤"}</span>
        </button>
        <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>
          {listening ? t("ask.listening", lang) : t("ask.hold", lang)}
        </p>

        {/* Text input */}
        <div style={{ width: "100%" }}>
          <p style={{ color: "var(--text-muted)", fontSize: "0.8rem", marginBottom: "8px" }}>{t("ask.type", lang)}</p>
          <div style={{ display: "flex", gap: "8px" }}>
            <input
              className="form-input"
              style={{ flex: 1 }}
              value={question}
              onChange={e => setQuestion(e.target.value)}
              placeholder={lang === "hi" ? "जैसे: क्या आज उर्वरा डाल सकते हैं?" : "e.g. Can I apply urea today?"}
              onKeyDown={e => e.key === "Enter" && submitQuestion(question)}
            />
            <button className="btn-primary" onClick={() => submitQuestion(question)} disabled={loading} style={{ minWidth: "64px" }}>
              {loading ? <span className="spinner" style={{ width: 18, height: 18 }} /> : t("ask.send", lang)}
            </button>
          </div>
        </div>

        {/* Answer */}
        {answer && (
          <div className="evidence-panel slide-up" style={{ width: "100%" }}>
            {!answer.grounded && (
              <div style={{ background: "#F5F5F5", borderRadius: "8px", padding: "6px 12px", marginBottom: "12px", fontSize: "0.75rem", color: "var(--text-muted)", display: "flex", alignItems: "center", gap: "6px" }}>
                <span>🔘</span> {t("ask.ungrounded", lang)}
              </div>
            )}
            <p style={{ fontSize: "1rem", lineHeight: 1.6, margin: 0 }}>{answer.text}</p>
            {answer.spoken && (
              <button className="speak-btn" onClick={() => speak(answer.spoken, lang)} style={{ marginTop: "12px", width: "100%" }}>
                ▶ {t("alert.listen", lang)}
              </button>
            )}
          </div>
        )}
      </div>

      <nav className="nav-bar">
        <button className="nav-item" onClick={onBack}><span style={{ fontSize: "1.3rem" }}>🔔</span><span>{t("nav.alerts", lang)}</span></button>
        <button className="nav-item active"><span style={{ fontSize: "1.3rem" }}>🎤</span><span>{t("nav.ask", lang)}</span></button>
        <button className="nav-item"><span style={{ fontSize: "1.3rem" }}>🌾</span><span>{t("nav.farm", lang)}</span></button>
      </nav>
    </main>
  );
}

// ─── My Farm tab ─────────────────────────────────────────────────────────────
function FarmTab({ farm, lang, farmId, onBack, onSave }: { farm: Farm | null; lang: Lang; farmId: string; onBack: () => void; onSave: () => void }) {
  const [crop, setCrop] = useState(farm?.crop || "paddy");
  const [sowing, setSowing] = useState(farm?.sowing_date?.slice(0, 10) || "");
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    try {
      await api.updateFarm(farmId, { crop, sowing_date: sowing });
      await api.triggerIngest().catch(() => {});
      onSave();
      onBack();
    } catch {
    } finally {
      setSaving(false);
    }
  }

  return (
    <main style={{ minHeight: "100dvh", background: "var(--surface-alt)" }}>
      <div className="top-header">
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <button onClick={onBack} style={{ background: "none", border: "none", color: "white", fontSize: "1.2rem", cursor: "pointer" }}>←</button>
          <h1 style={{ fontSize: "1.1rem", fontWeight: 700, color: "white", margin: 0 }}>{t("nav.farm", lang)}</h1>
        </div>
      </div>

      <div className="page-content">
        <div className="evidence-panel" style={{ marginBottom: "16px" }}>
          <div className="evidence-row"><span className="evidence-label">Farm ID</span><span className="evidence-value" style={{ fontSize: "0.8rem" }}>{farmId}</span></div>
          <div className="evidence-row"><span className="evidence-label">Village</span><span className="evidence-value">{farm?.village || "—"}</span></div>
          <div className="evidence-row"><span className="evidence-label">Growth Stage</span><span className="evidence-value">{farm?.growth_stage?.replace(/_/g, " ") || "—"}</span></div>
          <div className="evidence-row"><span className="evidence-label">Days After Sowing</span><span className="evidence-value">{farm?.days_after_sowing ?? "—"}</span></div>
          <div className="evidence-row"><span className="evidence-label">Area</span><span className="evidence-value">{farm?.area_ha} ha</span></div>
          <div className="evidence-row"><span className="evidence-label">Irrigation</span><span className="evidence-value">{t(`irrigation.${farm?.irrigation || "rainfed"}`, lang)}</span></div>
        </div>

        <div className="form-group">
          <label className="form-label">{t("onboarding.crop", lang)}</label>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
            {(["paddy", "maize", "wheat", "tomato"] as const).map(c => (
              <button
                key={c}
                onClick={() => setCrop(c)}
                style={{
                  padding: "12px", border: `2px solid ${crop === c ? "var(--accent)" : "#D4D9D4"}`,
                  borderRadius: "12px", background: crop === c ? "var(--accent-bg)" : "white",
                  color: crop === c ? "var(--accent)" : "var(--text-primary)",
                  fontWeight: 600, cursor: "pointer", minHeight: "48px", fontSize: "0.9rem",
                }}
              >
                {t(`crop.${c}`, lang)}
              </button>
            ))}
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">{t("onboarding.sowing", lang)}</label>
          <input className="form-input" type="date" value={sowing} onChange={e => setSowing(e.target.value)} />
        </div>

        <button className="btn-primary" onClick={save} disabled={saving} style={{ width: "100%" }}>
          {saving ? <span className="spinner" style={{ width: 18, height: 18 }} /> : "Save & Refresh Advisories"}
        </button>

        <div style={{ marginTop: "24px", textAlign: "center" }}>
          <button
            onClick={() => { localStorage.clear(); window.location.href = "/"; }}
            style={{ color: "var(--severe)", background: "none", border: "none", cursor: "pointer", fontSize: "0.85rem" }}
          >
            Reset & Start Over
          </button>
        </div>
      </div>

      <nav className="nav-bar">
        <button className="nav-item" onClick={onBack}><span style={{ fontSize: "1.3rem" }}>🔔</span><span>{t("nav.alerts", lang)}</span></button>
        <button className="nav-item"><span style={{ fontSize: "1.3rem" }}>🎤</span><span>{t("nav.ask", lang)}</span></button>
        <button className="nav-item active"><span style={{ fontSize: "1.3rem" }}>🌾</span><span>{t("nav.farm", lang)}</span></button>
      </nav>
    </main>
  );
}
