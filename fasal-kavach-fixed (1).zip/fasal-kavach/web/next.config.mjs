/** @type {import('next').NextConfig} */
const nextConfig = {
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
        ],
      },
    ];
  },
  async rewrites() {
    const apiBase = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:8080';
    return [
      { source: '/api/:path*', destination: `${apiBase}/api/:path*` },
      { source: '/internal/:path*', destination: `${apiBase}/internal/:path*` },
      { source: '/healthz', destination: `${apiBase}/healthz` },
    ];
  },
};

export default nextConfig;
